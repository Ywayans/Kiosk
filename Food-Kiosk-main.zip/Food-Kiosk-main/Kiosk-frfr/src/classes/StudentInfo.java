/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author Adrian
 */
public class StudentInfo {
    private String StudentId;
    private String StudentName;

    public void setStudentId(String StudentId) {
        this.StudentId = StudentId;
    }
    
    public String getStudentId() {
        return StudentId;
    }

    public void setStudentName(String StudentName) {
        this.StudentName = StudentName;
    }

    public String getStudentName() {
        return StudentName;
    }

    
    
}
